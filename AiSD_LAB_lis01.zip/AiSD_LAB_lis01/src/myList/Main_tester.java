package myList;

import java.util.ArrayList;
import java.util.Iterator;

public class Main_tester {

	public static void main(String[] args) 
	{
		MyList<Double> l = new MyList<Double>();
		l.ensureCapacity(10);
		l.add(8.0);
		l.add(9.5);
		l.add(6.2);
		l.add(null);
		l.add(7.5);
		
		l.add(9, 8.1);

//		l.clear();
//		l.remove(0);
//		System.out.println(l.contains(567.0));
//		System.out.println(l.get(0));
//		System.out.println(l.indexOf(8.0));
		l.first();
		for (Double i:l)
		{
			System.out.println(i);
		}
		
		

	}

}
