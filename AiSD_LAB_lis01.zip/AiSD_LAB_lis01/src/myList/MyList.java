package myList;


import java.util.Arrays;
import java.util.Iterator;



public class MyList <T> implements Iterable<T> {
	private Object[] array;
	private int pos = 0;
	private int size = 0;
	
	public MyList()
	{
		array = new Object[size];
		pos = 0;
	}
	
	public Object[] grow (int minCapacity)
	{
		int oldCapacity = array.length;
		if(oldCapacity > 0 && minCapacity > oldCapacity)
		{
			return array = Arrays.copyOf(array, minCapacity);
			
		}
		else 
		{
			return array = new Object[minCapacity];
		}
			
		
	}
	
	public Object[] grow () 
	{
		return grow(size + 1);
	}
	
	public void updateSize()
	{
		size = array.length;
	}
	
	public void add(int index, T element) 
	{
	
		if (index > size) throw new IndexOutOfBoundsException() ;
			
			Object [] tempTable = array;
			grow();
			updateSize();
			int j = 0;
			for(int i = 0; i < size; i++)
			{
				if (i != index)
				{
					array[i] = tempTable[j];
					j++;
				}
				else
				{
					array[i] = element;
				}
			}
	}
	
	
	public void add(T o)
	{
		grow();
		updateSize();
		array[size -1] = o;
	}
	
	public Object[] clear()
	{
		size = 0;
		return array = new Object[0];
	}
	
	public boolean contains(T o)
	{
		pos = 0;
		boolean b = false;
		if (o == null)
		{
			while(iterator().hasNext())
			{
				if ((iterator().next() == null))
						b = true;
			}
		}
		else
		{
			while (iterator().hasNext())
			{
				if(o.equals(iterator().next()))
				{
					b = true;
				}
			}
		}
		return b;
	}
	
	public void ensureCapacity(int minCapacity)
	{
		array = Arrays.copyOf(array, minCapacity);
		updateSize();
	}
	
	public T get (int index)
	{
		if (index > size)
		{
		throw new IndexOutOfBoundsException() ;
		}
		T obj = null;
		pos = 0;
		for (int i = 0; iterator().hasNext(); i++)
		{
			if(i == index)
			{
				obj = iterator().next();
			}
			else pos++;
		}
		return obj;
	}
	
	public int indexOf(T o)
	{
		pos = 0;
		int i = 0;
		if (o == null)
		{
			for (i = 0; iterator().hasNext(); i++)
			{
				if (iterator().next() == null) break;
			}
		}
		else
		{
		for (i = 0; iterator().hasNext(); i++)
		{
			if (o.equals(iterator().next())) break;
		}
		if (i > size -1) i = -1;
		}
		return i;
	}
	
	public T set (int index, T element)
	{
		if (index > size) throw new IndexOutOfBoundsException();
		pos = 0;
		T oldValue = get(index);
		array[index] = element;
		return oldValue;
		
	}
	
	public T remove(int index)
	{
		T oldValue = get(index);
		pos = 0;
		while (iterator().hasNext())
		{
			if (pos == index)
			iterator().remove();
			pos++;
		}
		size -= 1;
		pos = 0;
		return oldValue; 
	}
	
	public int size()
	{
		size = array.length;
		return size;
	}
	
	
	public void first ()
	{
		pos = 0;
	}
	
	
	
	@Override
	public Iterator<T> iterator() 
	{
		
		return new Iterator<T>() {
			
			@Override
			public boolean hasNext() {
				
				return pos < array.length;
			}

			@SuppressWarnings("unchecked")
			@Override
			public T next() throws IndexOutOfBoundsException
			{
				pos++;
				return (T) array [pos -1];
				
			}
			
			
						
			public void remove () 
			{ 
				int i = 0;
				Object [] tempTab = new Object[array.length -1];
				for(int temp = 0; temp < array.length ; temp++)
				{
					if (temp != pos)
					{
						tempTab[i] = (T) array [temp];
						i++;
					}
//					else temp++;
				}
				array = tempTab;
//				first();
				updateSize();
			}
			
		};
	}
	

}
